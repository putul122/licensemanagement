const defaultMentionStyle = {
  'backgroundColor': '#cee4e5'
}
export default defaultMentionStyle
