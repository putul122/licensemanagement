const SoftwareSummaryData = {
    resources: [
    {
    links: null,
    software_count: 0,
    cost: 0,
    cost_by_technology_classification: {
    Class 1: 120,
    Class 2: 200.2,
    Someting: 50
    },
    count_by_technology_classification: null
    }
    ],
    count: 1,
    result_code: 0,
    error_code: null,
    error_source: null,
    error_message: null,
    links: [ ]
    }

    export default SoftwareSummaryData
