import React from 'react'
import HandleAzure from '../../containers/handleAzure/handleAzureContainer'

class HandleAzurePageRoute extends React.Component {
  render () {
    return (
      <HandleAzure {...this.props} />
    )
  }
}
export default HandleAzurePageRoute
